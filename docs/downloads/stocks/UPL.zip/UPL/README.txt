QuantPredict - full pipeline output for UPL

plots/   the figures Quantpredict.py draws (price/volume history, model and ensemble
         accuracy, F1, confusion matrices, feature rankings, LSTM/ViT training curves,
         voting comparison, adaptive weights over time)
tables/  results.csv               every model, ensemble and feature-selected variant on the test period
         voting_comparison.csv     majority vs weighted vs adaptive weighted voting (STEP 18)
         validation_scores.csv     walk-forward validation scores (training period only)
         test_predictions.csv      day-by-day P(UP) and UP/DOWN calls for every model and ensemble
         price_history_adjusted.csv OHLCV after split/bonus back-adjustment
data/    summary.json / series.json  the same results in machine-readable form
pipeline_log.txt  the complete console output of the run

Next-day direction is close to a coin flip; nothing here is financial advice.
