QuantPredict - results for every NIFTY-50 stock in the dataset

summary/all_stocks.csv       one row per stock: best model, best ensemble, baseline, key accuracies
summary/all_results.csv      every stock x every model / ensemble / feature-selected variant
summary/method_averages.csv  each method averaged over all stocks
stocks/<SYMBOL>/             that stock's result tables and summary.json

Plots and the adjusted price history for each stock are in the per-stock downloads.
Next-day direction is close to a coin flip; nothing here is financial advice.
